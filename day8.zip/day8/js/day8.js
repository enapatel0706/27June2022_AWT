function ealertintrojs(){
    alert('ena')
    document.body.style.backgroundColor="green"
}
function econfirmintrojs(){
    confirm('ena')
    document.body.style.backgroundColor="red"
}
function epromptintrojs(){
    prompt('ena')
    document.body.style.backgroundColor="yellow"
}